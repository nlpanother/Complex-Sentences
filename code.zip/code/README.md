**Submission Code Release**

- Pytorch implementation for the submission [CITSAM: a Connection Information Triggered Sentiment Analysis Model for Complex Sentences]

- CITSAM-C.ipynb is the python code of CITSAM-C model
- CITSAM-S.ipynb is the python code of CITSAM-S model